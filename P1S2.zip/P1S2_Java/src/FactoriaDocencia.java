public abstract class FactoriaDocencia {
    abstract Aula crearAula(String nombre);

    abstract Grupo crearGrupo(String nombre);
}