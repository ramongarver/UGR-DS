class Aula
  def initialize(nombre)
    @nombre = nombre
  end

  attr_accessor :nombre
end
